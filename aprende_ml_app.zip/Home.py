import streamlit as st

st.set_page_config(page_title="Aprende ML Jugando", layout="wide")

st.title("🧠 Aprende Machine Learning Jugando")

st.markdown("""
Bienvenido a este recorrido interactivo por el mundo del **Machine Learning**.

Aquí aprenderás desde lo más básico hasta construir modelos con datos reales, de forma didáctica y visual.

### 📚 Módulos disponibles:
- 📊 KNN: Clasificación de frutas
- 📈 Regresión lineal: Predicción de precios
- 🔍 Clustering: Agrupamiento automático
- 🧠 Redes neuronales: Clasificación con perceptrón

Explora el menú a la izquierda y ¡empieza a experimentar! 🚀
""")